print('Welcome to another adventure!')
vim.g.python3_host_prog = '/usr/bin/python3'
require('globals')
require('plugins')
require('keymapping')
require('theme')
