This is the configuration file of nvim for the laptop Elephants
