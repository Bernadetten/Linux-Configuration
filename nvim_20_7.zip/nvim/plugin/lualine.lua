require('lualine').setup()
